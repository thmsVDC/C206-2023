package Model;

import java.util.Date;

public class NotaFiscal {
    private int id;
    private Date dataCompra;
    private int idPedido;

    public NotaFiscal(int id, Date dataCompra, int idPedido) {
        this.id = id;
        this.dataCompra = dataCompra;
        this.idPedido = idPedido;
    }

    public NotaFiscal() {
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public Date getDataCompra() {
        return dataCompra;
    }

    public void setDataCompra(Date dataCompra) {
        this.dataCompra = dataCompra;
    }

    public int getIdPedido() {
        return idPedido;
    }

    public void setIdPedido(int idPedido) {
        this.idPedido = idPedido;
    }
}
