package Model;

public class Pedido {
    private int idPedido;
    private String tipoPagamento;
    private String cliente_cpf;
    private int prazoEntrega;
    private float valorFrete;

    public Pedido(int idPedido, String tipoPagamento, String cliente_cpf, int prazoEntrega, float valorFrete) {
        this.idPedido = idPedido;
        this.tipoPagamento = tipoPagamento;
        this.cliente_cpf = cliente_cpf;
        this.prazoEntrega = prazoEntrega;
        this.valorFrete = valorFrete;
    }

    public Pedido() {
    }

    public int getIdPedido() {
        return idPedido;
    }

    public void setIdPedido(int idPedido) {
        this.idPedido = idPedido;
    }

    public String getTipoPagamento() {
        return tipoPagamento;
    }

    public void setTipoPagamento(String tipoPagamento) {
        this.tipoPagamento = tipoPagamento;
    }

    public String getCliente_cpf() {
        return cliente_cpf;
    }

    public void setCliente_cpf(String cliente_cpf) {
        this.cliente_cpf = cliente_cpf;
    }

    public int getPrazoEntrega() {
        return prazoEntrega;
    }

    public void setPrazoEntrega(int prazoEntrega) {
        this.prazoEntrega = prazoEntrega;
    }

    public float getValorFrete() {
        return valorFrete;
    }

    public void setValorFrete(float valorFrete) {
        this.valorFrete = valorFrete;
    }
}
