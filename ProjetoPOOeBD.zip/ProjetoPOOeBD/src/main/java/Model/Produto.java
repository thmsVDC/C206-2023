package Model;

public class Produto {
    private int idProduto;
    private String marca;
    private float preco;
    private String tecido;
    private int qtd;

    public Produto(int idProduto, String marca, float preco, String tecido, int qtd) {
        this.idProduto = idProduto;
        this.marca = marca;
        this.preco = preco;
        this.tecido = tecido;
        this.qtd = qtd;
    }

    public Produto() {
    }

    public int getIdProduto() {
        return idProduto;
    }

    public void setId(int idProduto) {
        this.idProduto = idProduto;
    }

    public String getMarca() {
        return marca;
    }

    public void setMarca(String marca) {
        this.marca = marca;
    }

    public float getPreco() {
        return preco;
    }

    public void setPreco(float preco) {
        this.preco = preco;
    }

    public String getTecido() {
        return tecido;
    }

    public void setTecido(String tecido) {
        this.tecido = tecido;
    }

    public int getQtd() {
        return qtd;
    }

    public void setQtd(int qtd) {
        this.qtd = qtd;
    }
}
