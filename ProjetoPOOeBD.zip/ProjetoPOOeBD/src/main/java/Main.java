import DAO.*;
import Model.*;

import java.util.Date;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        Date dataAtual = new Date();
        java.sql.Date dataCompra = new java.sql.Date(dataAtual.getTime());

        ClienteDAO clienteDAO = new ClienteDAO();
        Cliente cliente = new Cliente();

        ProdutoDAO produtoDAO = new ProdutoDAO();
        Produto produto = new Produto();

        PedidoDAO pedidoDAO = new PedidoDAO();
        Pedido pedido = new Pedido();

        NotaFiscal notaFiscal = new NotaFiscal();
        NotaFiscalDAO notaFiscalDAO = new NotaFiscalDAO();

        Pedido_has_Produto php = new Pedido_has_Produto();
        Pedido_has_ProdutoDAO phpDAO = new Pedido_has_ProdutoDAO();

        boolean controle = true;

        while (controle) {
            System.out.println("----- Lojas JM -----");
            System.out.println("Selecione abaixo o que será registrado");
            System.out.println("1. Cliente");
            System.out.println("2. Produto");
            System.out.println("3. Pedido");
            System.out.println("4. Sair");
            int op = sc.nextInt();

            switch (op) {
                case 1:
                    System.out.println("----- Clientes -----");
                    System.out.println("1. Adicionar cliente");
                    System.out.println("2. atualizar cliente");
                    System.out.println("3. Remover cliente");
                    System.out.println("4. Listar clientes");
                    System.out.println("5. Voltar");
                    op = sc.nextInt();

                    switch (op) {
                        case 1:

                            sc.nextLine();
                            System.out.println("--- Registro de cliente ---");
                            System.out.print("Nome: ");
                            cliente.setNome(sc.nextLine());

                            System.out.print("CPF: ");
                            cliente.setCpf(sc.nextLine());

                            System.out.print("E-mail: ");
                            cliente.setEmail(sc.nextLine());

                            System.out.print("Senha: ");
                            cliente.setSenha(sc.nextLine());

                            System.out.print("Telefone: ");
                            cliente.setTelefone(sc.nextLine());

                            clienteDAO.insertCliente(cliente);

                            break;
                        case 2:
                            Cliente clienteUpdate = new Cliente();
                            System.out.println("----- Atualizando cliente -----");
                            System.out.print("Digite o CPF do cliente: ");
                            sc.nextLine();
                            String cpf = sc.nextLine();

                            System.out.print("Nome: ");
                            clienteUpdate.setNome(sc.nextLine());

                            System.out.print("CPF: ");
                            clienteUpdate.setCpf(sc.nextLine());

                            System.out.print("E-mail: ");
                            clienteUpdate.setEmail(sc.nextLine());

                            System.out.print("Senha: ");
                            clienteUpdate.setSenha(sc.nextLine());

                            System.out.print("Telefone: ");
                            clienteUpdate.setTelefone(sc.nextLine());

                            clienteDAO.updateCliente(cpf, clienteUpdate);
                            break;
                        case 3:

                            clienteDAO.selectCliente();

                            System.out.println("----- Removendo cliente -----");
                            System.out.print("Digite o CPF do cliente que deseja deletar: ");
                            sc.nextLine();
                            clienteDAO.deleteCliente(sc.nextLine());
                            break;
                        case 4:
                            clienteDAO.selectCliente();
                            break;
                        case 5:
                            break;
                        default:
                            System.out.println("Entrada inválida");
                            break;
                    }

                    break;
                case 2:
                    System.out.println("----- Produtos -----");
                    System.out.println("1. Adicionar produto");
                    System.out.println("2. atualizar produto");
                    System.out.println("3. Remover produto");
                    System.out.println("4. Listar produtos");
                    System.out.println("5. Voltar");
                    op = sc.nextInt();

                    switch (op) {
                        case 1:

                            sc.nextLine();
                            System.out.println("--- Registro de produto ---");
                            System.out.print("Marca: ");
                            produto.setMarca(sc.nextLine());

                            System.out.print("Preço: ");
                            produto.setPreco(sc.nextFloat());

                            sc.nextLine();
                            System.out.print("Tecido: ");
                            produto.setTecido(sc.nextLine());

                            System.out.print("Quantidade: ");
                            produto.setQtd(sc.nextInt());

                            produtoDAO.insertProduto(produto);

                            break;
                        case 2:

                            Produto produtoUpdate = new Produto();
                            System.out.println("----- Atualizando produto -----");
                            System.out.print("Digite o ID do produto: ");
                            int id = sc.nextInt();
                            sc.nextLine();

                            System.out.print("Marca: ");
                            produtoUpdate.setMarca(sc.nextLine());

                            System.out.print("Preço: ");
                            produtoUpdate.setPreco(sc.nextFloat());
                            sc.nextLine();

                            System.out.print("Tecido: ");
                            produtoUpdate.setTecido(sc.nextLine());

                            System.out.print("Quantidade: ");
                            produtoUpdate.setQtd(sc.nextInt());

                            produtoDAO.updateProduto(id, produtoUpdate);

                            break;
                        case 3:

                            produtoDAO.selectProduto();

                            System.out.println("----- Removendo pedido -----");
                            System.out.print("Digite o ID do produto que deseja deletar: ");
                            produtoDAO.deleteProduto(sc.nextInt());

                            break;
                        case 4:
                            produtoDAO.selectProduto();
                            break;
                        case 5:
                            break;
                        default:
                            System.out.println("Entrada inválida");
                            break;
                    }

                    break;
                case 3:
                    System.out.println("----- Pedidos -----");
                    System.out.println("1. Adicionar pedido");
                    System.out.println("2. Adicionar produtos ao pedido");
                    System.out.println("3. atualizar pedido");
                    System.out.println("4. Remover pedido");
                    System.out.println("5. Listar pedidos e seus produtos");
                    System.out.println("6. Voltar");
                    op = sc.nextInt();

                    switch (op) {
                        case 1:

                            System.out.println("--- Adicionando um pedido ---");
                            int idPedidoAux;

                            System.out.println("ID do pedido: ");
                            idPedidoAux = sc.nextInt();
                            pedido.setIdPedido(idPedidoAux);

                            sc.nextLine();
                            System.out.print("Tipo do pagamento: ");
                            pedido.setTipoPagamento(sc.nextLine());

                            System.out.print("CPF do cliente: ");
                            pedido.setCliente_cpf(sc.nextLine());

                            System.out.print("Prazo de entrega: ");
                            pedido.setPrazoEntrega(sc.nextInt());

                            System.out.print("Valor do frete: ");
                            pedido.setValorFrete(sc.nextFloat());

                            pedidoDAO.insertPedido(pedido);

                            System.out.print("ID Nota Fiscal: ");
                            notaFiscal.setId(sc.nextInt());

                            notaFiscal.setDataCompra(dataCompra);

                            notaFiscal.setIdPedido(idPedidoAux);

                            notaFiscalDAO.insertNotaFiscal(notaFiscal);

                            break;
                        case 2:
                            System.out.println("----- Inserindo produtos no pedido -----");
                            pedidoDAO.selectPedido();
                            System.out.println("Selecione o ID do pedido: ");
                            php.setIdPedido(sc.nextInt());

                            System.out.println("Selecione os produtos do pedido");
                            produtoDAO.selectProduto();

                            String opcao;
                            do {
                                System.out.print("ID do produto: ");
                                php.setIdProduto(sc.nextInt());
                                sc.nextLine();

                                phpDAO.insertPHP(php);

                                System.out.println("Adicionar mais produtos? (Sim) (Nao)");
                                opcao = sc.nextLine();
                            } while (opcao.equalsIgnoreCase("sim"));

                            break;
                        case 3:

                            Pedido pedidoUpdate = new Pedido();
                            System.out.println("----- Atualizando pedido -----");
                            System.out.print("Digite o ID do pedido: ");
                            int id = sc.nextInt();

                            sc.nextLine();
                            System.out.print("Tipo do pagamento: ");
                            pedidoUpdate.setTipoPagamento(sc.nextLine());

                            System.out.print("CPF do cliente: ");
                            pedidoUpdate.setCliente_cpf(sc.nextLine());

                            System.out.println("Prazo de entrega: ");
                            pedidoUpdate.setPrazoEntrega(sc.nextInt());

                            System.out.print("Valor do frete: ");
                            pedidoUpdate.setValorFrete(sc.nextFloat());

                            pedidoDAO.updatePedido(id, pedidoUpdate);

                            break;
                        case 4:

                            pedidoDAO.selectPedido();

                            System.out.println("----- Removendo pedido -----");
                            System.out.print("Digite o ID do pedido que deseja deletar: ");
                            pedidoDAO.deletePedido(sc.nextInt());

                            break;
                        case 5:

                            phpDAO.selectPHP();

                            break;
                        case 6:
                            break;
                        default:

                            System.out.println("Entrada inválida");

                            break;
                    }

                    break;
                case 4:

                    controle = false;

                    break;
            }
        }
    }
}