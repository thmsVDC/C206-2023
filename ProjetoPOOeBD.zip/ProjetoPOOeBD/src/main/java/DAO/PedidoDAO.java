package DAO;
import Model.Pedido;

import java.sql.SQLException;
import java.util.ArrayList;

public class PedidoDAO extends ConnectionDAO {

    //DAO - Data Access Object
    boolean sucesso = false; //Para saber se funcionou

    //INSERT
    public boolean insertPedido(Pedido pedido) {

        connectToDB();

        String sql = "INSERT INTO Pedido (idPedido, tipoPagamento, cliente_cpf, prazoEntrega, valorFrete) values(?, ?, ?, ?, ?)";
        try {
            pst = con.prepareStatement(sql);
            pst.setInt(1, pedido.getIdPedido());
            pst.setString(2, pedido.getTipoPagamento());
            pst.setString(3, pedido.getCliente_cpf());
            pst.setInt(4, pedido.getPrazoEntrega());
            pst.setFloat(5, pedido.getValorFrete());
            pst.execute();
            sucesso = true;
        } catch (SQLException exc) {
            System.out.println("Erro: " + exc.getMessage());
            sucesso = false;
        } finally {
            try {
                con.close();
                pst.close();
            } catch (SQLException exc) {
                System.out.println("Erro: " + exc.getMessage());
            }
        }
        return sucesso;
    }

    //UPDATE
    public boolean updatePedido(int id, Pedido pedido) {
        connectToDB();
        String sql = "UPDATE Pedido SET idPedido = ? ,tipoPagamento = ?, cliente_cpf = ?, prazoEntrega = ?, valorFrete = ? where idPedido = ?";
        try {
            pst = con.prepareStatement(sql);
            pst.setInt(1, pedido.getIdPedido());
            pst.setString(2, pedido.getTipoPagamento());
            pst.setString(3, pedido.getCliente_cpf());
            pst.setInt(4, pedido.getPrazoEntrega());
            pst.setFloat(5, pedido.getValorFrete());
            pst.setInt(6, id);
            pst.execute();
            sucesso = true;
        } catch (SQLException ex) {
            System.out.println("Erro = " + ex.getMessage());
            sucesso = false;
        } finally {
            try {
                con.close();
                pst.close();
            } catch (SQLException exc) {
                System.out.println("Erro: " + exc.getMessage());
            }
        }
        return sucesso;
    }

    //DELETE
    public boolean deletePedido(int id) {
        connectToDB();
        String sql = "DELETE FROM Pedido where idPedido = ?";
        try {
            pst = con.prepareStatement(sql);
            pst.setInt(1, id);
            pst.execute();
            sucesso = true;
        } catch (SQLException ex) {
            System.out.println("Erro = " + ex.getMessage());
            sucesso = false;
        } finally {
            try {
                con.close();
                pst.close();
            } catch (SQLException exc) {
                System.out.println("Erro: " + exc.getMessage());
            }
        }
        return sucesso;
    }

    //SELECT
    public ArrayList<Pedido> selectPedido() {
        ArrayList<Pedido> pedidos = new ArrayList<>();
        connectToDB();
        String sql = "SELECT * FROM Pedido";

        try {
            st = con.createStatement();
            rs = st.executeQuery(sql);

            System.out.println("Lista de pedidos: ");

            while (rs.next()) {
                Pedido pedidoAux = new Pedido(rs.getInt("idPedido"), rs.getString("tipoPagamento"), rs.getString("cliente_cpf"), rs.getInt("prazoEntrega"), rs.getFloat("valorFrete"));

                System.out.println("idPedido = " + pedidoAux.getIdPedido());
                System.out.println("tipoPagamento = " + pedidoAux.getTipoPagamento());
                System.out.println("cliente_cpf = " + pedidoAux.getCliente_cpf());
                System.out.println("prazoEntrega = " + pedidoAux.getPrazoEntrega() + " dias úteis" );
                System.out.println("valorFrete: " + pedidoAux.getValorFrete());
                System.out.println("--------------------------------");


                pedidos.add(pedidoAux);
            }
            sucesso = true;
        } catch (SQLException e) {
            System.out.println("Erro: " + e.getMessage());
            sucesso = false;
        } finally {
            try {
                con.close();
                st.close();
            } catch (SQLException e) {
                System.out.println("Erro: " + e.getMessage());
            }
        }
        return pedidos;
    }
}
