package DAO;
import Model.Pedido_has_Produto;

import java.sql.SQLException;
import java.util.ArrayList;

public class Pedido_has_ProdutoDAO extends ConnectionDAO{

    //DAO - Data Access Object
    boolean sucesso = false; //Para saber se funcionou

    //INSERT
    public boolean insertPHP(Pedido_has_Produto php) {

        connectToDB();

        String sql = "INSERT INTO Pedido_has_Produto (idPedido, idProduto) values(?, ?)";
        try {
            pst = con.prepareStatement(sql);
            pst.setInt(1, php.getIdPedido());
            pst.setInt(2, php.getIdProduto());
            pst.execute();
            sucesso = true;
        } catch (SQLException exc) {
            System.out.println("Erro: " + exc.getMessage());
            sucesso = false;
        } finally {
            try {
                con.close();
                pst.close();
            } catch (SQLException exc) {
                System.out.println("Erro: " + exc.getMessage());
            }
        }
        return sucesso;
    }

    //UPDATE
    public boolean updatePHP(int id, Pedido_has_Produto php) {
        connectToDB();
        String sql = "UPDATE Pedido_has_Produto SET idPedido = ? ,idProduto = ? where id = ?";
        try {
            pst = con.prepareStatement(sql);
            pst.setInt(1, php.getIdPedido());
            pst.setInt(2, php.getIdProduto());
            pst.setInt(3,id);
            pst.execute();
            sucesso = true;
        } catch (SQLException ex) {
            System.out.println("Erro = " + ex.getMessage());
            sucesso = false;
        } finally {
            try {
                con.close();
                pst.close();
            } catch (SQLException exc) {
                System.out.println("Erro: " + exc.getMessage());
            }
        }
        return sucesso;
    }

    //DELETE
    public boolean deletePHP(int id) {
        connectToDB();
        String sql = "DELETE FROM Pedido_has_Produto where id = ?";
        try {
            pst = con.prepareStatement(sql);
            pst.setInt(1, id);
            pst.execute();
            sucesso = true;
        } catch (SQLException ex) {
            System.out.println("Erro = " + ex.getMessage());
            sucesso = false;
        } finally {
            try {
                con.close();
                pst.close();
            } catch (SQLException exc) {
                System.out.println("Erro: " + exc.getMessage());
            }
        }
        return sucesso;
    }

    //SELECT
    public ArrayList<Pedido_has_Produto> selectPHP() {
        ArrayList<Pedido_has_Produto> phps = new ArrayList<>();
        connectToDB();
        String sql = "SELECT * FROM Pedido_has_Produto";

        try {
            st = con.createStatement();
            rs = st.executeQuery(sql);

            System.out.println("Relação pedido - produto: ");

            while (rs.next()) {
                Pedido_has_Produto phpAux = new Pedido_has_Produto(rs.getInt("idProduto"),rs.getInt("idPedido"));

                System.out.println("idProduto = " + phpAux.getIdProduto());
                System.out.println("idPedido = " + phpAux.getIdPedido());
                System.out.println("--------------------------------");

                phps.add(phpAux);
            }
            sucesso = true;
        } catch (SQLException e) {
            System.out.println("Erro: " + e.getMessage());
            sucesso = false;
        } finally {
            try {
                con.close();
                st.close();
            } catch (SQLException e) {
                System.out.println("Erro: " + e.getMessage());
            }
        }
        return phps;
    }
}
