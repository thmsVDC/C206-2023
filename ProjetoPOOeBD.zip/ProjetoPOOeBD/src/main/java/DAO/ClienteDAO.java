package DAO;

import Model.Cliente;
import java.sql.SQLException;
import java.util.ArrayList;

public class ClienteDAO extends ConnectionDAO{

    //DAO - Data Access Object
    boolean sucesso = false; //Para saber se funcionou

    //INSERT
    public boolean insertCliente(Cliente cliente) {

        connectToDB();

        String sql = "INSERT INTO Cliente (cpf, nome, email, senha, telefone) values(?, ?, ?, ?, ?)";
        try {
            pst = con.prepareStatement(sql);
            pst.setString(1, cliente.getCpf());
            pst.setString(2, cliente.getNome());
            pst.setString(3, cliente.getEmail());
            pst.setString(4, cliente.getSenha());
            pst.setString(5, cliente.getTelefone());
            pst.execute();
            sucesso = true;
        } catch (SQLException exc) {
            System.out.println("Erro: " + exc.getMessage());
            sucesso = false;
        } finally {
            try {
                con.close();
                pst.close();
            } catch (SQLException exc) {
                System.out.println("Erro: " + exc.getMessage());
            }
        }
        return sucesso;
    }

    //UPDATE
    public boolean updateCliente(String id, Cliente cliente) {
        connectToDB();
        String sql = "UPDATE Cliente SET cpf = ? ,nome = ?, email = ?, senha = ?, telefone = ? where cpf = ?";
        try {
            pst = con.prepareStatement(sql);
            pst.setString(1, cliente.getCpf());
            pst.setString(2, cliente.getNome());
            pst.setString(3, cliente.getEmail());
            pst.setString(4, cliente.getSenha());
            pst.setString(5, cliente.getTelefone());
            pst.setString(6,id);
            pst.execute();
            sucesso = true;
        } catch (SQLException ex) {
            System.out.println("Erro = " + ex.getMessage());
            sucesso = false;
        } finally {
            try {
                con.close();
                pst.close();
            } catch (SQLException exc) {
                System.out.println("Erro: " + exc.getMessage());
            }
        }
        return sucesso;
    }

    //DELETE
    public boolean deleteCliente(String id) {
        connectToDB();
        String sql = "DELETE FROM Cliente where cpf = ?";
        try {
            pst = con.prepareStatement(sql);
            pst.setString(1, id);
            pst.execute();
            sucesso = true;
        } catch (SQLException ex) {
            System.out.println("Erro = " + ex.getMessage());
            sucesso = false;
        } finally {
            try {
                con.close();
                pst.close();
            } catch (SQLException exc) {
                System.out.println("Erro: " + exc.getMessage());
            }
        }
        return sucesso;
    }

    //SELECT
    public ArrayList<Cliente> selectCliente() {
        ArrayList<Cliente> clientes = new ArrayList<>();
        connectToDB();
        String sql = "SELECT * FROM Cliente";

        try {
            st = con.createStatement();
            rs = st.executeQuery(sql);

            System.out.println("Lista de clientes: ");

            while (rs.next()) {
                Cliente clienteAux = new Cliente(rs.getString("cpf"),rs.getString("nome"), rs.getString("email"),rs.getString("senha"),rs.getString("telefone"));

                System.out.println("cpf = " + clienteAux.getCpf());
                System.out.println("nome = " + clienteAux.getNome());
                System.out.println("email = " + clienteAux.getEmail());
                System.out.println("senha = " + clienteAux.getSenha());
                System.out.println("telefone = " + clienteAux.getTelefone());
                System.out.println("--------------------------------");

                clientes.add(clienteAux);
            }
            sucesso = true;
        } catch (SQLException e) {
            System.out.println("Erro: " + e.getMessage());
            sucesso = false;
        } finally {
            try {
                con.close();
                st.close();
            } catch (SQLException e) {
                System.out.println("Erro: " + e.getMessage());
            }
        }
        return clientes;
    }
}
