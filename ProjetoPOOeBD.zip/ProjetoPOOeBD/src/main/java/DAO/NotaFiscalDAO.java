package DAO;
import Model.NotaFiscal;

import java.sql.Date;
import java.sql.SQLException;
import java.util.ArrayList;

public class NotaFiscalDAO extends ConnectionDAO {

    //DAO - Data Access Object
    boolean sucesso = false; //Para saber se funcionou

    //INSERT
    public boolean insertNotaFiscal(NotaFiscal notaFiscal) {

        connectToDB();

        String sql = "INSERT INTO NotaFiscal (idNotaFiscal, dataCompra, idPedido) values(?, ?, ?)";
        try {
            pst = con.prepareStatement(sql);
            pst.setInt(1, notaFiscal.getId());
            pst.setDate(2, (Date) notaFiscal.getDataCompra());
            pst.setInt(3, notaFiscal.getIdPedido());
            pst.execute();
            sucesso = true;
        } catch (SQLException exc) {
            System.out.println("Erro: " + exc.getMessage());
            sucesso = false;
        } finally {
            try {
                con.close();
                pst.close();
            } catch (SQLException exc) {
                System.out.println("Erro: " + exc.getMessage());
            }
        }
        return sucesso;
    }

    //UPDATE
    public boolean updateNotaFiscal(int id, NotaFiscal notaFiscal) {
        connectToDB();
        String sql = "UPDATE NotaFiscal SET idNotaFiscal = ?, dataCompra = ?, idPedido = ? where idNotaFiscal = ?";
        try {
            pst = con.prepareStatement(sql);
            pst.setInt(1, notaFiscal.getId());
            pst.setDate(2, (Date) notaFiscal.getDataCompra());
            pst.setInt(3, notaFiscal.getIdPedido());
            pst.setInt(4,id);
            pst.execute();
            sucesso = true;
        } catch (SQLException ex) {
            System.out.println("Erro = " + ex.getMessage());
            sucesso = false;
        } finally {
            try {
                con.close();
                pst.close();
            } catch (SQLException exc) {
                System.out.println("Erro: " + exc.getMessage());
            }
        }
        return sucesso;
    }

    //DELETE
    public boolean deleteNotaFiscal(int id) {
        connectToDB();
        String sql = "DELETE FROM NotaFiscal where idNotaFiscal = ?";
        try {
            pst = con.prepareStatement(sql);
            pst.setInt(1, id);
            pst.execute();
            sucesso = true;
        } catch (SQLException ex) {
            System.out.println("Erro = " + ex.getMessage());
            sucesso = false;
        } finally {
            try {
                con.close();
                pst.close();
            } catch (SQLException exc) {
                System.out.println("Erro: " + exc.getMessage());
            }
        }
        return sucesso;
    }

    //SELECT
    public ArrayList<NotaFiscal> selectNotaFiscal() {
        ArrayList<NotaFiscal> notasFiscais = new ArrayList<>();
        connectToDB();
        String sql = "SELECT * FROM NotaFiscal";

        try {
            st = con.createStatement();
            rs = st.executeQuery(sql);

            System.out.println("Lista de Notas fiscais: ");

            while (rs.next()) {
                NotaFiscal notaFiscalAux = new NotaFiscal(rs.getInt("id"),rs.getDate("dataCompra"), rs.getInt("idPedido"));

                System.out.println("id = " + notaFiscalAux.getId());
                System.out.println("dataCompra = " + notaFiscalAux.getDataCompra());
                System.out.println("idPedido = " + notaFiscalAux.getIdPedido());
                System.out.println("--------------------------------");

                notasFiscais.add(notaFiscalAux);
            }
            sucesso = true;
        } catch (SQLException e) {
            System.out.println("Erro: " + e.getMessage());
            sucesso = false;
        } finally {
            try {
                con.close();
                st.close();
            } catch (SQLException e) {
                System.out.println("Erro: " + e.getMessage());
            }
        }
        return notasFiscais;
    }
}
